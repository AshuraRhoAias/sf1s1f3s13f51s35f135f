const authService = require('../services/auth.service');

class AuthController {

    async register(req, res, next) {
        try {
            const { email, password, nombre } = req.body;

            if (!email || !password || !nombre) {
                return res.status(400).json({
                    error: 'Todos los campos son requeridos'
                });
            }

            const result = await authService.register(email, password, nombre);

            res.status(201).json(result);
        } catch (error) {
            next(error);
        }
    }

    async login(req, res, next) {
        try {
            const { email, password } = req.body;

            if (!email || !password) {
                return res.status(400).json({
                    error: 'Email y contraseña requeridos'
                });
            }

            const result = await authService.login(email, password);

            res.json(result);
        } catch (error) {
            next(error);
        }
    }

    // NUEVO: Descifrar password con frase maestra
    async decryptPassword(req, res, next) {
        try {
            const { userId, masterPhrase } = req.body;

            if (!userId || !masterPhrase) {
                return res.status(400).json({
                    error: 'Usuario ID y frase maestra requeridos'
                });
            }

            // Verificar que el usuario autenticado tiene permisos (opcional)
            // Solo administradores o el mismo usuario
            if (req.user.id !== parseInt(userId) && req.user.role !== 'admin') {
                return res.status(403).json({
                    error: 'No tienes permisos para descifrar este password'
                });
            }

            const result = await authService.decryptUserPassword(userId, masterPhrase);

            res.json(result);
        } catch (error) {
            if (error.message === 'Frase maestra incorrecta') {
                return res.status(401).json({ error: error.message });
            }
            next(error);
        }
    }
}

module.exports = new AuthController();