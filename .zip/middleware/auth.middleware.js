// middlewares/auth.middleware.js
const jwtService = require('../services/jwt.service');
const authService = require('../services/auth.service');

const authMiddleware = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];

        if (!token) {
            return res.status(401).json({ error: 'Token no proporcionado' });
        }

        // Verificar token JWT
        const decoded = jwtService.verifyToken(token);

        // Validar que la sesión existe y está activa
        const isValidSession = await authService.validateSession(decoded.jti);

        if (!isValidSession) {
            return res.status(401).json({ error: 'Sesión inválida o expirada' });
        }

        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Token inválido' });
    }
};

module.exports = authMiddleware;