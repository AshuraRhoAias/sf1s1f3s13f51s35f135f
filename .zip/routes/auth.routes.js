const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const authMiddleware = require('../middleware/auth.middleware');
const rateLimiter = require('../middleware/rateLimiter.middleware');

// Rutas públicas
router.post('/register', rateLimiter(5, 15), authController.register);
router.post('/login', rateLimiter(10, 15), authController.login);

// Rutas protegidas
router.post('/decrypt-password', authMiddleware, rateLimiter(3, 60), authController.decryptPassword);

module.exports = router;